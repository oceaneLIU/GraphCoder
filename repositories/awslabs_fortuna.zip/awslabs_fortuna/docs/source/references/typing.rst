Typing
===========
These section contains Fortuna's custom typings.

.. autoclass:: fortuna.typing.Array
.. autoclass:: fortuna.typing.Batch
.. autoclass:: fortuna.typing.Params
.. autoclass:: fortuna.typing.Mutable
.. autoclass:: fortuna.typing.Path
.. autoclass:: fortuna.typing.OptaxOptimizer
.. autoclass:: fortuna.typing.CalibParams
.. autoclass:: fortuna.typing.CalibMutable
.. autoclass:: fortuna.typing.Status
