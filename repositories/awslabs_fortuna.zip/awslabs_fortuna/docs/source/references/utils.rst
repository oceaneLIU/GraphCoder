Utils
==========
The probabilistic model automatically handles random number generator updates via a
:ref:`random number generator <random_number_generator>` object.
Please find its reference below.

.. _random_number_generator:

.. autoclass:: fortuna.utils.random.RandomNumberGenerator
