Plot
===========
This section includes the plotting functionalities currently supported by Fortuna.

.. autofunction:: fortuna.plot.plot_reliability_diagram
