Deep Ensemble
--------------

.. autoclass:: fortuna.prob_model.posterior.deep_ensemble.deep_ensemble_approximator.DeepEnsemblePosteriorApproximator

.. autoclass:: fortuna.prob_model.posterior.deep_ensemble.deep_ensemble_posterior.DeepEnsemblePosterior
    :show-inheritance:
    :no-inherited-members:
    :exclude-members: state
    :members: fit, sample, load_state, save_state

