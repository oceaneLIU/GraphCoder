.. _builtin_models:

Built-in models
===============
We support several built-in models:

.. toctree::
   :maxdepth: 1

   mlp
   cnn
   resnet
   wideresnet