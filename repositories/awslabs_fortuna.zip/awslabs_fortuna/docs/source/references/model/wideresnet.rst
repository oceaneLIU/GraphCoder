WideResNet
============================

.. autoclass:: fortuna.model.wideresnet.WideResNet
    :no-undoc-members:
    :no-inherited-members:
    :no-members:
    :show-inheritance:

.. autoclass:: fortuna.model.wideresnet.WideResNet28_10
