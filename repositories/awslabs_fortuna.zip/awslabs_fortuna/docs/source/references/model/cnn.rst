CNN
============================

.. autoclass:: fortuna.model.lenet.LeNet5
    :no-undoc-members:
    :no-inherited-members:
    :no-members:
    :show-inheritance: