ResNet
============================

.. autoclass:: fortuna.model.resnet.ResNet
    :no-undoc-members:
    :no-inherited-members:
    :no-members:
    :show-inheritance:

.. autoclass:: fortuna.model.resnet.ResNet18

.. autoclass:: fortuna.model.resnet.ResNet34

.. autoclass:: fortuna.model.resnet.ResNet50

.. autoclass:: fortuna.model.resnet.ResNet101

.. autoclass:: fortuna.model.resnet.ResNet152

.. autoclass:: fortuna.model.resnet.ResNet200
