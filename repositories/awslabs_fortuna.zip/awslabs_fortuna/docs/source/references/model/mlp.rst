Multi-Layer Perceptron (MLP)
============================

.. autoclass:: fortuna.model.mlp.MLP
    :no-undoc-members:
    :no-inherited-members:
    :no-members:
    :show-inheritance:
