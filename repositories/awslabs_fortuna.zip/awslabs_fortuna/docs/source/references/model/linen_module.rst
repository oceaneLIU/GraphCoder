Flax Linen Module
=================
.. automodule:: flax.linen.Module