.. _usage_modes:

Usage modes
######################
This section explains some of Fortuna's main usage modes.

.. toctree::
   :maxdepth: 1
   :caption: CONTENTS:

   uncertainty_estimates
   model_outputs
   flax_models
