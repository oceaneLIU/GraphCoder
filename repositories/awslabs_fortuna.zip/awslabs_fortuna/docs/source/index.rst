.. include:: landingpage.rst

.. toctree::
   :maxdepth: 1
   :hidden:
   :caption: CONTENTS:

   quickstart
   installation
   examples/examples
   usage_modes/usage_modes
   references/references
   methods
