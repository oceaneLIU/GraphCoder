from fortuna.prob_model.prior.gaussian import (DiagonalGaussianPrior,
                                               IsotropicGaussianPrior, Prior)
