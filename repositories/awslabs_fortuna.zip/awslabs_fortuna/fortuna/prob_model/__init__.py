from fortuna.prob_model.classification import ProbClassifier
from fortuna.prob_model.regression import ProbRegressor
