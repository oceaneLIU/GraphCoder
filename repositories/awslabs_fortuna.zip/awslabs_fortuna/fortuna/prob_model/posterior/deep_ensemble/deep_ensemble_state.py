from typing import List

from fortuna.prob_model.posterior.map.map_state import MAPState

DeepEnsembleState = List[MAPState]
