SWAG_NAME = "swag"
