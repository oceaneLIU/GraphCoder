package group.aelysium.rustyconnector.toolkit.velocity.family;

public enum UnavailableProtocol {
    CANCEL_CONNECTION_ATTEMPT,
    ASSIGN_NEW_HOME,
    CONNECT_WITH_ERROR,
}
