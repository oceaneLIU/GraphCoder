package group.aelysium.rustyconnector.toolkit.velocity.config;

public interface DefaultConfig {
    boolean whitelist_enabled();
    String whitelist_name();
    Integer magicLink_serverTimeout();
    Integer magicLink_serverPingInterval();
}
