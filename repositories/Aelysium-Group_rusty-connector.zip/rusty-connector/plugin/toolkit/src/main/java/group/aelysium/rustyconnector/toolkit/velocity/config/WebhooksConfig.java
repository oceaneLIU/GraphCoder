package group.aelysium.rustyconnector.toolkit.velocity.config;

public interface WebhooksConfig {
}
