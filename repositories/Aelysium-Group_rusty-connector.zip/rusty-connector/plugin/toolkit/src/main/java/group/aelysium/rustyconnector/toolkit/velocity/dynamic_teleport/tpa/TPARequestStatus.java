package group.aelysium.rustyconnector.toolkit.velocity.dynamic_teleport.tpa;

enum TPARequestStatus {
    NOT_SENT,
    REQUESTED,
    ACCEPTED,
    DENIED,
    EXPIRED,
    STALE
}
