package group.aelysium.rustyconnector.toolkit.velocity.config;

public interface MagicMCLoaderConfig {
    String family();
    int weight();
    int playerCap_soft();
    int playerCap_hard();
}
