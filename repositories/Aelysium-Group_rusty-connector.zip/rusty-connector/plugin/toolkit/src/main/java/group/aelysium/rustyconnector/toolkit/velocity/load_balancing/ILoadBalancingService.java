package group.aelysium.rustyconnector.toolkit.velocity.load_balancing;

import group.aelysium.rustyconnector.toolkit.core.serviceable.interfaces.Service;

public interface ILoadBalancingService extends Service {}
