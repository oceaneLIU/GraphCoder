package group.aelysium.rustyconnector.toolkit.velocity.family.scalar_family;

public interface IRootFamily extends IScalarFamily {
}
