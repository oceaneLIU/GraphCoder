package group.aelysium.rustyconnector.toolkit.mc_loader.events.magic_link;

import group.aelysium.rustyconnector.toolkit.core.events.Event;

public class DisconnectedEvent implements Event {
    public DisconnectedEvent() {}
}
