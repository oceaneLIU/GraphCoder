package group.aelysium.rustyconnector.toolkit.velocity.family.scalar_family;

import group.aelysium.rustyconnector.toolkit.velocity.family.IFamily;

public interface IScalarFamily extends IFamily {
}
