package group.aelysium.rustyconnector.toolkit.velocity.parties;

public enum SwitchPower {
    MINIMAL,
    MODERATE,
    AGGRESSIVE
}
