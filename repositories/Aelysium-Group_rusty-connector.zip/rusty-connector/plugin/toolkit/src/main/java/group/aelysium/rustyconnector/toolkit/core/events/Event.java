package group.aelysium.rustyconnector.toolkit.core.events;

public interface Event {
}
