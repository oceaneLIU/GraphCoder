package group.aelysium.rustyconnector.toolkit.core.server;

public enum ServerAssignment {
    GENERIC,
    RANKED_GAME_SERVER
}
