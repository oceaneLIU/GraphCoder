package group.aelysium.rustyconnector.toolkit.core;

import com.google.gson.JsonObject;

public interface JSONParseable {
    JsonObject toJSON();
}
