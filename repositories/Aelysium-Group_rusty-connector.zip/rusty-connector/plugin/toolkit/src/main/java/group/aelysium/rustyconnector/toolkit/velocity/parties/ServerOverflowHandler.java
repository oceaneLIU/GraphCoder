package group.aelysium.rustyconnector.toolkit.velocity.parties;

public enum ServerOverflowHandler {
    KICK_FROM_PARTY,
    STAY_BEHIND,
    HARD_BLOCK
}
