package group.aelysium.rustyconnector.plugin.velocity.lib.matchmaking.rank;

public class DefaultRankAdapter {
}
