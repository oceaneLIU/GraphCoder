package group.aelysium.rustyconnector.plugin.velocity.lib.webhook;

public enum WebhookScope {
    PROXY,
    FAMILY
}
