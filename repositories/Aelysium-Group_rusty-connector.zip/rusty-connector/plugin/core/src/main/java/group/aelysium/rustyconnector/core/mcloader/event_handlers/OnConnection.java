package group.aelysium.rustyconnector.core.mcloader.event_handlers;

import group.aelysium.rustyconnector.toolkit.core.events.Listener;
import group.aelysium.rustyconnector.toolkit.mc_loader.events.magic_link.ConnectedEvent;

public class OnConnection implements Listener<ConnectedEvent> {
    public void handler(ConnectedEvent event) {
    }
}