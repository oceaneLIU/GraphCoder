package group.aelysium.rustyconnector.core.mcloader.event_handlers;

import group.aelysium.rustyconnector.toolkit.core.events.Listener;
import group.aelysium.rustyconnector.toolkit.mc_loader.events.magic_link.TimeoutEvent;

public class OnTimeout implements Listener<TimeoutEvent> {
    public void handler(TimeoutEvent event) {
    }
}