package group.aelysium.rustyconnector.core.lib.messenger;

public abstract class MessengerConnection {
}