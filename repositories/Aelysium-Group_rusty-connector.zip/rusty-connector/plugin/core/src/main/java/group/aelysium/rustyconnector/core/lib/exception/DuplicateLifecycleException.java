package group.aelysium.rustyconnector.core.lib.exception;

public class DuplicateLifecycleException extends Exception {
    public DuplicateLifecycleException(String errorMessage) {
        super(errorMessage);
    }
}
