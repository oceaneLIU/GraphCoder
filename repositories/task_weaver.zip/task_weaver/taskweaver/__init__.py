__author__ = "Microsoft TaskWeaver"
__email__ = "taskweaver@microsoft.com"
__version__ = "0.0.0"  # Refer to `/version.json` file when updating version string, the line is auto-updated
