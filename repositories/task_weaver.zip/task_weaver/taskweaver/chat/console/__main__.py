from .chat import chat_taskweaver

if __name__ == "__main__":
    chat_taskweaver()
