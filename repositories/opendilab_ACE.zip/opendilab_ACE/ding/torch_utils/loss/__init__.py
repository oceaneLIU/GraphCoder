from .cross_entropy_loss import LabelSmoothCELoss, SoftFocalLoss, build_ce_criterion
from .multi_logits_loss import MultiLogitsLoss
