from .action import TaskRefuse, DisconnectionRefuse, ConnectionRefuse, TaskFail
from .slave import Slave
