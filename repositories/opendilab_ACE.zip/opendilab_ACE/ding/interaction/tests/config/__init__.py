from .test_base import TestInteractionConfig
