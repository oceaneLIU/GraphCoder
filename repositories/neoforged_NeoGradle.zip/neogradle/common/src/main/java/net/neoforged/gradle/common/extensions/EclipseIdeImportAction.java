package net.neoforged.gradle.common.extensions;

import org.gradle.api.Project;
import org.gradle.plugins.ide.eclipse.model.EclipseModel;


