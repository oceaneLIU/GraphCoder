package net.neoforged.gradle.common.util.hash;

public interface Hashable {
    void appendToHasher(Hasher var1);
}