package net.neoforged.gradle.common.tasks;

import net.neoforged.gradle.dsl.common.tasks.NeoGradleBase;

public abstract class IdePostSyncExecutionTask extends NeoGradleBase {
}
