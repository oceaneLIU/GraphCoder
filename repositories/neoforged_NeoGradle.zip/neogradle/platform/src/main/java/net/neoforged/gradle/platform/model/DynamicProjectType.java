package net.neoforged.gradle.platform.model;

public enum DynamicProjectType {
    CLEAN,
    NEO_FORM,
    PLATFORM,
    RUNTIME
}
