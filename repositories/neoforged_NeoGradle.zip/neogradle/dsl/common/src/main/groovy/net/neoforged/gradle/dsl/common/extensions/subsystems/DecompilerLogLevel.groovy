package net.neoforged.gradle.dsl.common.extensions.subsystems

enum DecompilerLogLevel {
    TRACE,
    INFO,
    WARN,
    ERROR
}
